import { ArrowUpRight, CircleHelp, Leaf, Menu } from 'lucide-react';

export function Topbar({ activePage, farmName, onOpenMobileMenu, onOpenTutorial }) {
  return (
    <header className="sticky top-0 z-20 flex min-h-16 items-center justify-between border-b border-[#e1e3d8] bg-[#f7f6f0]/95 px-4 backdrop-blur-md sm:px-6 lg:px-9">
      <div className="flex min-w-0 items-center gap-3">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          aria-label="Abrir menu de navegação"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[#dfe2d7] bg-white text-[#415b44] transition-colors hover:bg-[#eff1e8] lg:hidden"
        >
          <Menu className="h-[18px] w-[18px]" />
        </button>

        <div className="min-w-0">
          <div className="flex items-center gap-1.5 truncate text-xs text-[#7b8173]">
            <Leaf aria-hidden="true" className="h-3.5 w-3.5 shrink-0 text-[#65805b]" />
            <span className="truncate">{farmName}</span>
          </div>
          <p aria-current="page" className="truncate text-sm font-semibold text-[#28352a]">
            {activePage === 'Dashboard' ? 'Visão geral' : activePage}
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={onOpenTutorial}
        className="inline-flex min-h-10 items-center gap-2 rounded-full border border-[#dfe2d5] bg-white px-3.5 text-xs font-medium text-[#425743] shadow-[0_1px_2px_rgba(38,51,39,.04)] transition-colors hover:border-[#c5cfb9] hover:bg-[#f1f3eb] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#608254]"
      >
        <CircleHelp className="h-4 w-4 text-[#718a5f]" />
        <span className="hidden sm:inline">Guia do drone</span>
        <span className="sm:hidden">Ajuda</span>
        <ArrowUpRight aria-hidden="true" className="hidden h-3.5 w-3.5 text-[#898f80] sm:block" />
      </button>
    </header>
  );
}
